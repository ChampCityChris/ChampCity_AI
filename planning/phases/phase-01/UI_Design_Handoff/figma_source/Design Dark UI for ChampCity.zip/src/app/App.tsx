import { useState } from "react";
import logoImage from "@/imports/ChampCity_AI.png";
import {
  FileText,
  Wand2,
  ShieldAlert,
  Zap,
  ClipboardList,
  CheckSquare,
  Archive,
  Copy,
  Save,
  AlertTriangle,
  Info,
  CheckCircle,
  X,
  Upload,
  ChevronDown,
  ChevronRight,
  Eye,
  FolderOpen,
  ArrowRight,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen =
  | "new-work-card"
  | "architect-prompt"
  | "risk-router"
  | "builder-prompt"
  | "builder-report"
  | "human-validation"
  | "phase-closeout";

type RiskLevel = "low" | "medium" | "high";

type WorkCardStatus =
  | "ready_for_architect"
  | "ready_for_builder"
  | "validated"
  | "closed";

interface WorkCard {
  id: string;
  title: string;
  phase: string;
  status: WorkCardStatus;
  riskLevel: RiskLevel;
}

// ─── Demo data ────────────────────────────────────────────────────────────────

const DEMO_CARDS: WorkCard[] = [
  {
    id: "WC01",
    title: "Define Work Card schema and Markdown renderer",
    phase: "phase-01",
    status: "ready_for_builder",
    riskLevel: "low",
  },
  {
    id: "WC02",
    title: "Build new Work Card capture form",
    phase: "phase-01",
    status: "ready_for_architect",
    riskLevel: "medium",
  },
  {
    id: "WC09",
    title: "Prepare Figma UI design handoff package",
    phase: "phase-01",
    status: "ready_for_architect",
    riskLevel: "medium",
  },
];

const PHASES = ["phase-01", "phase-02", "phase-03"];

const RISK_CATEGORIES = [
  {
    name: "Authentication or authorization",
    level: "high" as RiskLevel,
    description:
      "The Work Card mentions login, permissions, sessions, roles, or related access-control behavior.",
    matched: "auth, authentication",
    question:
      "Is this asking Builder to change authentication or authorization behavior?",
  },
  {
    name: "Database or migration changes",
    level: "high" as RiskLevel,
    description:
      "The Work Card mentions database, schema, migration, or persistence-layer changes.",
    matched: "database",
    question:
      "Does this Work Card require database or migration work that should be isolated into a smaller card?",
  },
  {
    name: "Cloud, deployment, or infrastructure",
    level: "high" as RiskLevel,
    description:
      "The Work Card mentions deployment, hosting, cloud, infrastructure, or CI/CD work.",
    matched: "cloud, deployment",
    question:
      "Can this be completed without changing cloud, deployment, or infrastructure settings?",
  },
  {
    name: "External API or provider integration",
    level: "high" as RiskLevel,
    description:
      "The Work Card mentions provider SDKs, external APIs, network calls, or third-party integrations.",
    matched: "provider sdk, sdk",
    question: "Can this be implemented without adding a provider SDK yet?",
  },
];

const ARTIFACT_SUMMARY: Record<string, string[]> = {
  "Work Cards": [
    "WC01_define_work_card_schema_and_markdown_renderer.json",
    "WC02_build_new_work_card_capture_form.json",
  ],
  "Architect Prompts": ["ARCHITECT_PROMPT_WC01.md"],
  "Risk Reviews": [],
  "Builder Prompts": ["BUILDER_PROMPT_WC01.md"],
  "Builder Reports": ["BUILDER_REPORT_WC01_work_card_schema_renderer.md"],
  "Validation Reports": [],
  "Repair Prompts": [],
  "Closeout Reports": [],
};

// ─── Utilities ────────────────────────────────────────────────────────────────

function cn(...classes: (string | undefined | false | null)[]): string {
  return classes.filter(Boolean).join(" ");
}

function riskColor(level: RiskLevel): string {
  if (level === "high") return "text-red-400 bg-red-400/10 border-red-400/20";
  if (level === "medium")
    return "text-amber-400 bg-amber-400/10 border-amber-400/20";
  return "text-emerald-400 bg-emerald-400/10 border-emerald-400/20";
}

function statusColor(status: WorkCardStatus): string {
  if (status === "ready_for_architect")
    return "text-blue-400 bg-blue-400/10 border-blue-400/20";
  if (status === "ready_for_builder")
    return "text-primary bg-primary/10 border-primary/20";
  if (status === "validated")
    return "text-emerald-400 bg-emerald-400/10 border-emerald-400/20";
  return "text-muted-foreground bg-muted border-border";
}

// ─── CSS constants ────────────────────────────────────────────────────────────

const inputCls =
  "w-full bg-white/[0.04] border border-border rounded-md px-3 py-1.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary/40 focus:border-primary/40 transition-colors";
const selectCls =
  "w-full bg-[#0e1218] border border-border rounded-md px-3 py-1.5 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40 focus:border-primary/40 transition-colors cursor-pointer [color-scheme:dark]";
const textareaCls =
  inputCls + " resize-none leading-relaxed min-h-[64px] py-2";

// ─── Pipeline steps (source of truth for nav + stepper) ──────────────────────

const PIPELINE: {
  id: Screen;
  label: string;
  mode: "architect" | "implementer";
  shortDesc: string;
}[] = [
  {
    id: "new-work-card",
    label: "Capture",
    mode: "architect",
    shortDesc: "Define intent",
  },
  {
    id: "architect-prompt",
    label: "Architect",
    mode: "architect",
    shortDesc: "Refine scope",
  },
  {
    id: "risk-router",
    label: "Risk",
    mode: "architect",
    shortDesc: "Pre-flight check",
  },
  {
    id: "builder-prompt",
    label: "Implement",
    mode: "implementer",
    shortDesc: "Implementer handoff",
  },
  {
    id: "builder-report",
    label: "Report",
    mode: "implementer",
    shortDesc: "Capture evidence",
  },
  {
    id: "human-validation",
    label: "Validate",
    mode: "implementer",
    shortDesc: "Confirm it worked",
  },
  {
    id: "phase-closeout",
    label: "Closeout",
    mode: "implementer",
    shortDesc: "Phase decision",
  },
];

// ─── Atoms ────────────────────────────────────────────────────────────────────

function Badge({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center px-1.5 py-0.5 rounded border text-[10px] font-semibold tracking-wide uppercase leading-none",
        className
      )}
    >
      {children}
    </span>
  );
}

function RiskBadge({ level }: { level: RiskLevel }) {
  return <Badge className={riskColor(level)}>{level}</Badge>;
}

function StatusBadge({ status }: { status: WorkCardStatus }) {
  return (
    <Badge className={statusColor(status)}>{status.replace(/_/g, " ")}</Badge>
  );
}

type NoticeType = "warning" | "error" | "info" | "success";

function Notice({
  type,
  children,
}: {
  type: NoticeType;
  children: React.ReactNode;
}) {
  const styles: Record<NoticeType, string> = {
    warning: "bg-amber-500/8 border-amber-500/25 text-amber-100/85",
    error: "bg-red-500/8 border-red-500/25 text-red-100/85",
    info: "bg-blue-500/8 border-blue-500/25 text-blue-100/85",
    success: "bg-emerald-500/8 border-emerald-500/25 text-emerald-100/85",
  };
  const icons: Record<NoticeType, React.ReactNode> = {
    warning: (
      <AlertTriangle size={12} className="text-amber-400 shrink-0 mt-px" />
    ),
    error: <X size={12} className="text-red-400 shrink-0 mt-px" />,
    info: <Info size={12} className="text-blue-400 shrink-0 mt-px" />,
    success: (
      <CheckCircle size={12} className="text-emerald-400 shrink-0 mt-px" />
    ),
  };
  return (
    <div
      className={cn(
        "flex gap-2 p-3 rounded-lg border text-xs leading-relaxed",
        styles[type]
      )}
    >
      {icons[type]}
      <div>{children}</div>
    </div>
  );
}

function MonoBlock({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "font-mono text-xs text-foreground/55 bg-black/30 rounded-lg p-4 border border-white/[0.05] overflow-auto",
        className
      )}
    >
      <pre className="whitespace-pre-wrap leading-relaxed">{children}</pre>
    </div>
  );
}

function FilenameDisplay({ filename }: { filename: string }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-white/[0.03] border border-border">
      <FolderOpen size={11} className="text-muted-foreground/60 shrink-0" />
      <span className="font-mono text-[11px] text-foreground/65 truncate leading-none">
        {filename}
      </span>
    </div>
  );
}

function EmptyState({
  message,
  icon,
}: {
  message: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-14 text-center">
      <div className="text-muted-foreground/20">
        {icon || <FolderOpen size={22} />}
      </div>
      <p className="text-xs text-muted-foreground/50 max-w-[200px] leading-relaxed">
        {message}
      </p>
    </div>
  );
}

// ─── Form primitives ──────────────────────────────────────────────────────────

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      <label className="text-[11px] font-medium text-muted-foreground/70 leading-none">
        {label}
      </label>
      {children}
    </div>
  );
}

function FieldRow({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-2 gap-3">{children}</div>;
}

function FieldGroup({
  title,
  children,
}: {
  title?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-3">
      {title && (
        <div className="flex items-center gap-2">
          <span className="text-[9px] font-bold tracking-[0.14em] uppercase text-muted-foreground/35">
            {title}
          </span>
          <div className="flex-1 h-px bg-white/[0.05]" />
        </div>
      )}
      {children}
    </div>
  );
}

// ─── Work Card Summary ────────────────────────────────────────────────────────

function WorkCardSummary({ card }: { card: WorkCard }) {
  return (
    <div className="rounded-lg border border-border bg-white/[0.02] p-3 grid grid-cols-2 gap-x-3 gap-y-2.5">
      {(
        [
          { label: "ID", value: card.id, mono: true },
          { label: "Title", value: card.title },
          { label: "Status", value: <StatusBadge status={card.status} /> },
          { label: "Phase", value: card.phase, mono: true },
          { label: "Risk", value: <RiskBadge level={card.riskLevel} /> },
        ] as { label: string; value: React.ReactNode; mono?: boolean }[]
      ).map(({ label, value, mono }) => (
        <div key={label}>
          <div className="text-[9px] uppercase tracking-[0.1em] text-muted-foreground/35 mb-0.5 font-semibold">
            {label}
          </div>
          {typeof value === "string" ? (
            <div
              className={cn(
                "text-xs text-foreground leading-snug",
                mono && "font-mono"
              )}
            >
              {value}
            </div>
          ) : (
            value
          )}
        </div>
      ))}
    </div>
  );
}

// ─── Action Bar (left pane footer) ───────────────────────────────────────────

interface ActionBarProps {
  onPreview?: () => void;
  onSave?: () => void;
  onCopy?: () => void;
  saveLabel?: string;
  copyLabel?: string;
  saveDisabled?: boolean;
  copyDisabled?: boolean;
  statusMessage?: string;
  statusType?: "success" | "error";
}

function ActionBar({
  onPreview,
  onSave,
  onCopy,
  saveLabel = "Save",
  copyLabel = "Copy",
  saveDisabled,
  copyDisabled,
  statusMessage,
  statusType = "success",
}: ActionBarProps) {
  return (
    <div className="flex items-center justify-between pt-3 mt-1 border-t border-white/[0.05]">
      <div className="min-h-[20px] flex items-center">
        {statusMessage && (
          <span
            className={cn(
              "text-[11px] flex items-center gap-1.5 font-medium",
              statusType === "success" ? "text-emerald-400" : "text-red-400"
            )}
          >
            {statusType === "success" ? (
              <CheckCircle size={11} />
            ) : (
              <X size={11} />
            )}
            {statusMessage}
          </span>
        )}
      </div>
      <div className="flex items-center gap-2">
        {onPreview && (
          <button
            onClick={onPreview}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-border text-xs text-muted-foreground hover:text-foreground hover:bg-white/[0.04] transition-colors"
          >
            <Eye size={12} />
            Preview
          </button>
        )}
        {onCopy && (
          <button
            disabled={copyDisabled}
            onClick={onCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-border text-xs text-muted-foreground hover:text-foreground hover:bg-white/[0.04] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <Copy size={12} />
            {copyLabel}
          </button>
        )}
        {onSave && (
          <button
            disabled={saveDisabled}
            onClick={onSave}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/85 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            <Save size={12} />
            {saveLabel}
          </button>
        )}
      </div>
    </div>
  );
}

// ─── Artifact Context Panel (right pane) ──────────────────────────────────────

interface ArtifactPanelProps {
  eyebrow?: string;
  title: string;
  status?: string;
  filename?: string;
  onCopy?: () => void;
  onSave?: () => void;
  copyLabel?: string;
  saveLabel?: string;
  copyDisabled?: boolean;
  saveDisabled?: boolean;
  children?: React.ReactNode;
  emptyMessage?: string;
  emptyIcon?: React.ReactNode;
}

function ArtifactPanel({
  eyebrow,
  title,
  status,
  filename,
  onCopy,
  onSave,
  copyLabel = "Copy",
  saveLabel = "Save",
  copyDisabled,
  saveDisabled,
  children,
  emptyMessage,
  emptyIcon,
}: ArtifactPanelProps) {
  return (
    <div className="p-5 flex flex-col gap-4 h-full">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          {eyebrow && (
            <div className="text-[9px] uppercase tracking-[0.14em] font-bold text-primary/55 mb-1">
              {eyebrow}
            </div>
          )}
          <h2 className="text-sm font-semibold text-foreground leading-tight">
            {title}
          </h2>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {status && (
            <span className="text-[10px] text-muted-foreground/50 bg-white/[0.03] px-2 py-1 rounded border border-border whitespace-nowrap">
              {status}
            </span>
          )}
          {onCopy && (
            <button
              disabled={copyDisabled}
              onClick={onCopy}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md border border-border text-xs text-muted-foreground hover:text-foreground hover:bg-white/[0.04] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <Copy size={11} />
              {copyLabel}
            </button>
          )}
          {onSave && (
            <button
              disabled={saveDisabled}
              onClick={onSave}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/85 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <Save size={11} />
              {saveLabel}
            </button>
          )}
        </div>
      </div>

      {filename && <FilenameDisplay filename={filename} />}

      <div className="flex-1">
        {children || (
          <EmptyState
            message={emptyMessage || "Nothing to preview yet."}
            icon={emptyIcon}
          />
        )}
      </div>
    </div>
  );
}

// ─── Screen Layout ────────────────────────────────────────────────────────────

function ScreenLayout({
  left,
  right,
}: {
  left: React.ReactNode;
  right: React.ReactNode;
}) {
  return (
    <div className="flex h-full overflow-hidden">
      <div className="w-[380px] shrink-0 border-r border-border flex flex-col overflow-y-auto">
        {left}
      </div>
      <div className="flex-1 flex flex-col overflow-y-auto bg-card/20">
        {right}
      </div>
    </div>
  );
}

// ─── Pipeline Stepper ─────────────────────────────────────────────────────────

function PipelineStepper({
  active,
  onNav,
}: {
  active: Screen;
  onNav: (s: Screen) => void;
}) {
  const activeIndex = PIPELINE.findIndex((s) => s.id === active);

  const renderStep = (
    step: (typeof PIPELINE)[0],
    globalIndex: number,
    larger = false
  ) => {
    const isActive = step.id === active;
    const isDone = globalIndex < activeIndex;
    return (
      <button
        key={step.id}
        onClick={() => onNav(step.id)}
        title={step.shortDesc}
        className={cn(
          "flex items-center gap-1.5 rounded-md font-medium transition-all",
          larger ? "px-3 py-2 text-sm" : "px-2.5 py-1.5 text-xs",
          isActive && step.mode === "architect" && "bg-blue-500/12 text-blue-300",
          isActive && step.mode === "implementer" && "bg-primary/12 text-primary",
          !isActive && isDone && "text-muted-foreground/80 hover:text-foreground hover:bg-white/[0.04]",
          !isActive && !isDone && "text-muted-foreground/55 hover:text-muted-foreground hover:bg-white/[0.03]"
        )}
      >
        <div
          className={cn(
            "rounded-full shrink-0 transition-colors",
            larger ? "w-2 h-2" : "w-1.5 h-1.5",
            isActive && step.mode === "architect" && "bg-blue-400",
            isActive && step.mode === "implementer" && "bg-primary",
            !isActive && isDone && "bg-muted-foreground/45",
            !isActive && !isDone && "bg-muted-foreground/20"
          )}
        />
        {step.label}
      </button>
    );
  };

  const architectSteps = PIPELINE.slice(0, 3);   // Capture · Architect · Risk
  const implementerSteps = PIPELINE.slice(3, 5); // Implement · Report
  const finalSteps = PIPELINE.slice(5);           // Validate · Closeout (larger)

  return (
    <div className="flex items-end gap-0">

      {/* ── Architect group ──────────────────────────────── */}
      <div className="flex flex-col items-center gap-1">
        <span className="text-[9px] uppercase tracking-[0.18em] font-bold text-blue-400/70 leading-none">
          Architect
        </span>
        <div className="flex items-center">
          {architectSteps.map((step, i) => (

            <div key={step.id} className="flex items-center">
              {renderStep(step, i)}
              {i < architectSteps.length - 1 && (
                <ChevronRight size={9} className="text-muted-foreground/15 mx-0.5" />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* ── Large "/" divider ────────────────────────────── */}
      <span className="text-3xl font-thin text-muted-foreground/45 leading-none mx-3 mb-0.5">
        /
      </span>

      {/* ── Implementer group ────────────────────────────── */}
      <div className="flex flex-col items-center gap-1">
        <span className="text-[9px] uppercase tracking-[0.18em] font-bold text-primary/70 leading-none">
          Implementer
        </span>
        <div className="flex items-center">
          {implementerSteps.map((step, i) => (
            <div key={step.id} className="flex items-center">
              {renderStep(step, i + 3)}
              {i < implementerSteps.length - 1 && (
                <ChevronRight size={9} className="text-muted-foreground/15 mx-0.5" />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* ── Validate · Closeout — slightly larger ─────────── */}
      <div className="flex items-center ml-3 pl-3 border-l border-white/[0.07]">
        {finalSteps.map((step, i) => (
          <div key={step.id} className="flex items-center">
            {renderStep(step, i + 5, true)}
            {i < finalSteps.length - 1 && (
              <ChevronRight size={10} className="text-muted-foreground/15 mx-1" />
            )}
          </div>
        ))}
      </div>

    </div>
  );
}

// ─── App Header ───────────────────────────────────────────────────────────────

interface AppHeaderProps {
  active: Screen;
  onNav: (s: Screen) => void;
  phase: string;
  onPhaseChange: (p: string) => void;
  activeCard: WorkCard | null;
  onCardChange: (c: WorkCard | null) => void;
}

function AppHeader({
  active,
  onNav,
  phase,
  onPhaseChange,
  activeCard,
  onCardChange,
}: AppHeaderProps) {
  return (
    <header className="h-16 shrink-0 flex items-center gap-4 px-5 border-b border-border bg-card/70 backdrop-blur-sm">
      {/* Brand — logo image */}
      <div className="shrink-0 pr-4 border-r border-border flex items-center">
        <img
          src={logoImage}
          alt="ChampCity A/I — Architect / Implementer"
          className="h-11 w-auto object-contain"
        />
      </div>

      {/* Pipeline stepper — centered */}
      <div className="flex-1 flex items-center justify-center">
        <PipelineStepper active={active} onNav={onNav} />
      </div>

      {/* Context controls */}
      <div className="shrink-0 flex items-center gap-2 pl-4 border-l border-border">
        <select
          value={phase}
          onChange={(e) => onPhaseChange(e.target.value)}
          className={cn(
            selectCls,
            "w-[100px] text-xs py-1.5 font-mono"
          )}
        >
          {PHASES.map((p) => (
            <option key={p}>{p}</option>
          ))}
        </select>

        <select
          value={activeCard?.id || ""}
          onChange={(e) =>
            onCardChange(
              DEMO_CARDS.find((c) => c.id === e.target.value) || null
            )
          }
          className={cn(
            selectCls,
            "w-[200px] text-xs py-1.5"
          )}
        >
          <option value="">— Select Work Card —</option>
          {DEMO_CARDS.map((c) => (
            <option key={c.id} value={c.id}>
              {c.id} — {c.title.length > 30 ? c.title.slice(0, 30) + "…" : c.title}
            </option>
          ))}
        </select>

        {activeCard && (
          <div className="flex items-center gap-1.5">
            <RiskBadge level={activeCard.riskLevel} />
            <StatusBadge status={activeCard.status} />
          </div>
        )}
      </div>
    </header>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN 1 — New Work Card  (Capture)
// ═══════════════════════════════════════════════════════════════════════════════

function NewWorkCardScreen({ activeCard }: { activeCard: WorkCard | null }) {
  const [form, setForm] = useState({
    id: activeCard?.id || "WC09",
    title: activeCard?.title || "",
    phase: activeCard?.phase || "phase-01",
    riskLevel: activeCard?.riskLevel || "medium",
    problem: "",
    importance: "",
    outcome: "",
    included: "",
    excluded: "",
    knownFiles: "",
    evidence: "",
    risks: "",
    notes: "",
  });
  const [previewed, setPreviewed] = useState(false);
  const [savedPath, setSavedPath] = useState<string | null>(null);

  const set =
    (k: string) =>
    (
      e: React.ChangeEvent<
        HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
      >
    ) =>
      setForm((f) => ({ ...f, [k]: e.target.value }));

  const slug = (form.title || "draft")
    .toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[^a-z0-9_]/g, "");

  const previewContent = `# Work Card ${form.id || "WC09"}

**Title:** ${form.title || "(untitled)"}
**Phase:** ${form.phase}
**Risk Level:** ${form.riskLevel}
**Status:** ready_for_architect
**Created:** ${new Date().toISOString().slice(0, 10)}

## What are you trying to build or fix?
${form.problem || "(not entered)"}

## Why does this matter?
${form.importance || "(not entered)"}

## User Outcome
${form.outcome || "(not entered)"}

## Included Scope
${form.included || "(not entered)"}

## Out of Scope
${form.excluded || "(not entered)"}

## Known Files or Systems
${form.knownFiles || "(not entered)"}

## Evidence or Examples
${form.evidence || "(not entered)"}

## Concerns or Risks
${form.risks || "(not entered)"}

## Operator Notes
${form.notes || "(not entered)"}`;

  return (
    <ScreenLayout
      left={
        <div className="p-4 flex flex-col gap-5">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h1 className="text-sm font-semibold text-foreground">
                New Work Card
              </h1>
              <p className="text-xs text-muted-foreground/60 mt-0.5 leading-snug">
                Tell the system what you want to build or fix.
              </p>
            </div>
            <StatusBadge status="ready_for_architect" />
          </div>

          <FieldGroup title="Identity">
            <FieldRow>
              <Field label="Work Card ID">
                <input
                  className={inputCls}
                  value={form.id}
                  onChange={set("id")}
                  placeholder="WC09"
                />
              </Field>
              <Field label="Phase">
                <select
                  className={selectCls}
                  value={form.phase}
                  onChange={set("phase")}
                >
                  {PHASES.map((p) => (
                    <option key={p}>{p}</option>
                  ))}
                </select>
              </Field>
            </FieldRow>
            <Field label="Title">
              <input
                className={inputCls}
                value={form.title}
                onChange={set("title")}
                placeholder="Short descriptive title"
              />
            </Field>
            <Field label="Risk Level">
              <select
                className={selectCls}
                value={form.riskLevel}
                onChange={set("riskLevel")}
              >
                <option>low</option>
                <option>medium</option>
                <option>high</option>
              </select>
            </Field>
          </FieldGroup>

          <FieldGroup title="What are you building?">
            <Field label="What are you trying to build or fix?">
              <textarea
                className={textareaCls}
                value={form.problem}
                onChange={set("problem")}
                rows={3}
                placeholder="Describe in plain language…"
              />
            </Field>
            <Field label="Why does this matter?">
              <textarea
                className={textareaCls}
                value={form.importance}
                onChange={set("importance")}
                rows={2}
                placeholder="What problem does this solve?"
              />
            </Field>
            <Field label="What should the user be able to do when done?">
              <textarea
                className={textareaCls}
                value={form.outcome}
                onChange={set("outcome")}
                rows={2}
                placeholder="Describe the outcome from the user's perspective…"
              />
            </Field>
          </FieldGroup>

          <FieldGroup title="What's in and out?">
            <FieldRow>
              <Field label="What should be included?">
                <textarea
                  className={textareaCls}
                  value={form.included}
                  onChange={set("included")}
                  rows={2}
                />
              </Field>
              <Field label="What should NOT be included?">
                <textarea
                  className={textareaCls}
                  value={form.excluded}
                  onChange={set("excluded")}
                  rows={2}
                />
              </Field>
            </FieldRow>
          </FieldGroup>

          <FieldGroup title="Context and evidence">
            <FieldRow>
              <Field label="Known files, screens, or systems">
                <textarea
                  className={textareaCls}
                  value={form.knownFiles}
                  onChange={set("knownFiles")}
                  rows={2}
                />
              </Field>
              <Field label="Evidence or examples">
                <textarea
                  className={textareaCls}
                  value={form.evidence}
                  onChange={set("evidence")}
                  rows={2}
                />
              </Field>
            </FieldRow>
            <FieldRow>
              <Field label="Concerns or risks">
                <textarea
                  className={textareaCls}
                  value={form.risks}
                  onChange={set("risks")}
                  rows={2}
                />
              </Field>
              <Field label="Operator notes">
                <textarea
                  className={textareaCls}
                  value={form.notes}
                  onChange={set("notes")}
                  rows={2}
                />
              </Field>
            </FieldRow>
          </FieldGroup>

          {savedPath && (
            <Notice type="success">
              Saved — <span className="font-mono">{savedPath}</span>
            </Notice>
          )}

          <ActionBar
            onPreview={() => setPreviewed(true)}
            onSave={() =>
              setSavedPath(
                `planning/phases/${form.phase}/Work_Cards/${form.id}_${slug}.json`
              )
            }
            saveLabel="Save Work Card"
            statusMessage={savedPath ? "Work Card saved" : undefined}
            statusType="success"
          />
        </div>
      }
      right={
        <ArtifactPanel
          eyebrow="Markdown Preview"
          title="Work Card Draft"
          status={
            previewed ? "Draft status: ready_for_architect" : undefined
          }
          filename={
            previewed
              ? `planning/phases/${form.phase}/Work_Cards/${form.id}_${slug}.json`
              : undefined
          }
          emptyMessage="Click Preview to see the Work Card draft before saving."
          emptyIcon={<Eye size={22} />}
        >
          {previewed ? (
            <MonoBlock className="max-h-[calc(100vh-180px)]">
              {previewContent}
            </MonoBlock>
          ) : undefined}
        </ArtifactPanel>
      }
    />
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN 2 — Architect Prompt Composer
// ═══════════════════════════════════════════════════════════════════════════════

function ArchitectPromptScreen({
  activeCard,
}: {
  activeCard: WorkCard | null;
}) {
  const [selectedCard, setSelectedCard] = useState<WorkCard | null>(activeCard);
  const [copied, setCopied] = useState(false);
  const [savedPath, setSavedPath] = useState<string | null>(null);

  const prompt = selectedCard
    ? `You are acting as Architect for ChampCity A/I.

The Architect translates Operator intent into a Builder-ready Work Card. Your job is NOT to build anything. Your job is to clarify, frame, bound, and confirm the Work Card is ready for Implementer handoff.

## Selected Work Card

Work Card ID: ${selectedCard.id}
Title: ${selectedCard.title}
Phase: ${selectedCard.phase}
Status: ${selectedCard.status}
Risk Level: ${selectedCard.riskLevel}

---

## Architect Review Instructions

Review the Work Card above and:

1. Identify any intent that is vague, ambiguous, or missing.
2. Ask 2–3 focused clarifying questions the Operator should answer before the work is handed to Builder.
3. Flag any scope-creep risks — items that look small but could expand significantly.
4. Recommend a safe, minimal implementation approach.
5. Confirm when the Work Card is ready for Implementer handoff.

## What the Architect will produce

- A sharpened Work Card interpretation.
- Clarifying questions with suggested default answers.
- A scope boundary recommendation.
- A "ready for Builder" or "needs revision" verdict.
`
    : null;

  const handleCopy = () => {
    if (!prompt) return;
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ScreenLayout
      left={
        <div className="p-4 flex flex-col gap-5">
          <div>
            <h1 className="text-sm font-semibold text-foreground">
              Architect Prompt Composer
            </h1>
            <p className="text-xs text-muted-foreground/60 mt-0.5 leading-snug">
              Have the Architect refine the Work Card before Builder handoff.
            </p>
          </div>

          <Notice type="info">
            Only Work Cards with JSON artifacts can be selected.
            Markdown-only notes are not app-readable Work Cards.
          </Notice>

          <FieldGroup title="Source">
            <Field label="Phase">
              <select className={selectCls}>
                {PHASES.map((p) => (
                  <option key={p}>{p}</option>
                ))}
              </select>
            </Field>
            <Field label="Saved Work Card">
              <select
                className={selectCls}
                value={selectedCard?.id || ""}
                onChange={(e) => {
                  setSelectedCard(
                    DEMO_CARDS.find((c) => c.id === e.target.value) || null
                  );
                  setSavedPath(null);
                }}
              >
                <option value="">— select a Work Card —</option>
                {DEMO_CARDS.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.id} — {c.title} ({c.phase})
                  </option>
                ))}
              </select>
            </Field>
          </FieldGroup>

          {selectedCard ? (
            <>
              <WorkCardSummary card={selectedCard} />
              {selectedCard.status !== "ready_for_architect" && (
                <Notice type="warning">
                  This Work Card status is{" "}
                  <strong>{selectedCard.status.replace(/_/g, " ")}</strong>,
                  not{" "}
                  <span className="font-mono">ready_for_architect</span>. You
                  can still generate a prompt, but review before sending.
                </Notice>
              )}
            </>
          ) : (
            <EmptyState
              message="Select a saved Work Card JSON to generate an Architect prompt."
              icon={<Wand2 size={22} />}
            />
          )}

          {savedPath && (
            <Notice type="success">
              Saved — <span className="font-mono">{savedPath}</span>
            </Notice>
          )}

          <ActionBar
            onCopy={selectedCard ? handleCopy : undefined}
            onSave={
              selectedCard
                ? () =>
                    setSavedPath(
                      `planning/phases/phase-01/Architect_Prompts/ARCHITECT_PROMPT_${selectedCard.id}.md`
                    )
                : undefined
            }
            copyLabel={copied ? "Copied!" : "Copy Prompt"}
            saveLabel="Save Prompt"
            copyDisabled={!selectedCard}
            saveDisabled={!selectedCard}
            statusMessage={
              copied
                ? "Copied to clipboard"
                : savedPath
                ? "Prompt saved"
                : undefined
            }
            statusType="success"
          />
        </div>
      }
      right={
        <ArtifactPanel
          eyebrow="Architect Prompt"
          title={
            selectedCard
              ? `Framing Prompt — ${selectedCard.id}`
              : "Framing Prompt"
          }
          status={prompt ? "Prompt generated." : undefined}
          filename={
            savedPath
              ? `planning/phases/phase-01/Architect_Prompts/ARCHITECT_PROMPT_${selectedCard?.id}.md`
              : undefined
          }
          onCopy={selectedCard ? handleCopy : undefined}
          copyLabel={copied ? "Copied!" : "Copy"}
          copyDisabled={!selectedCard}
          emptyMessage="Select a Work Card to preview the Architect framing prompt."
          emptyIcon={<Wand2 size={22} />}
        >
          {prompt ? (
            <MonoBlock className="max-h-[calc(100vh-180px)]">
              {prompt}
            </MonoBlock>
          ) : undefined}
        </ArtifactPanel>
      }
    />
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN 3 — Risk Router
// ═══════════════════════════════════════════════════════════════════════════════

function RiskCategoryCard({ cat }: { cat: (typeof RISK_CATEGORIES)[0] }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-lg border border-border bg-white/[0.02] overflow-hidden">
      <button
        className="w-full flex items-center justify-between px-3 py-2.5 text-left hover:bg-white/[0.03] transition-colors"
        onClick={() => setOpen(!open)}
      >
        <div className="flex items-center gap-2.5">
          <RiskBadge level={cat.level} />
          <span className="text-xs font-medium text-foreground">
            {cat.name}
          </span>
        </div>
        {open ? (
          <ChevronDown size={12} className="text-muted-foreground shrink-0" />
        ) : (
          <ChevronRight size={12} className="text-muted-foreground shrink-0" />
        )}
      </button>
      {open && (
        <div className="px-3 pb-3 flex flex-col gap-2 border-t border-border pt-2.5">
          <p className="text-xs text-muted-foreground leading-relaxed">
            {cat.description}
          </p>
          <div className="text-[11px] text-foreground/55">
            Matched terms:{" "}
            <span className="font-mono text-foreground/75">{cat.matched}</span>
          </div>
          <div className="text-xs text-blue-300/75 italic leading-relaxed">
            {cat.question}
          </div>
        </div>
      )}
    </div>
  );
}

function RiskRouterScreen({ activeCard }: { activeCard: WorkCard | null }) {
  const [selectedCard, setSelectedCard] = useState<WorkCard | null>(
    activeCard || DEMO_CARDS[0]
  );
  const [savedPath, setSavedPath] = useState<string | null>(null);

  const isHighRisk = RISK_CATEGORIES.length > 0;
  const isLowRisk =
    selectedCard?.riskLevel === "low" && RISK_CATEGORIES.length === 0;

  return (
    <ScreenLayout
      left={
        <div className="p-4 flex flex-col gap-5">
          <div>
            <h1 className="text-sm font-semibold text-foreground">
              Risk Router
            </h1>
            <p className="text-xs text-muted-foreground/60 mt-0.5 leading-snug">
              Identify whether this Work Card needs extra caution before
              implementation.
            </p>
          </div>

          <FieldGroup title="Source">
            <Field label="Phase">
              <select className={selectCls}>
                <option>phase-01</option>
              </select>
            </Field>
            <Field label="Saved Work Card">
              <select
                className={selectCls}
                value={selectedCard?.id || ""}
                onChange={(e) => {
                  setSelectedCard(
                    DEMO_CARDS.find((c) => c.id === e.target.value) || null
                  );
                  setSavedPath(null);
                }}
              >
                <option value="">— select a Work Card —</option>
                {DEMO_CARDS.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.id} — {c.title} ({c.phase})
                  </option>
                ))}
              </select>
            </Field>
          </FieldGroup>

          {selectedCard ? (
            <WorkCardSummary card={selectedCard} />
          ) : (
            <EmptyState
              message="Select a saved Work Card to run deterministic risk routing."
              icon={<ShieldAlert size={22} />}
            />
          )}

          {savedPath && (
            <Notice type="success">
              Saved — <span className="font-mono">{savedPath}</span>
            </Notice>
          )}

          <ActionBar
            onSave={
              selectedCard
                ? () =>
                    setSavedPath(
                      `planning/phases/phase-01/Risk_Reviews/RISK_REVIEW_${selectedCard.id}.md`
                    )
                : undefined
            }
            saveLabel="Save Risk Review"
            saveDisabled={!selectedCard}
            statusMessage={savedPath ? "Risk review saved" : undefined}
            statusType="success"
          />
        </div>
      }
      right={
        <div className="p-5 flex flex-col gap-5">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-[9px] uppercase tracking-[0.14em] font-bold text-primary/55 mb-1">
                Deterministic
              </div>
              <h2 className="text-sm font-semibold text-foreground">
                Risk Review
              </h2>
            </div>
            {selectedCard && (
              <span className="text-[10px] text-muted-foreground/50 bg-white/[0.03] px-2 py-1 rounded border border-border">
                Risk review generated.
              </span>
            )}
          </div>

          {selectedCard ? (
            <>
              <div className="rounded-lg border border-border bg-card p-4 grid grid-cols-2 gap-4">
                <div>
                  <div className="text-[9px] uppercase tracking-[0.1em] text-muted-foreground/35 mb-1 font-semibold">
                    Work Card ID
                  </div>
                  <div className="text-sm font-mono font-medium">
                    {selectedCard.id}
                  </div>
                </div>
                <div>
                  <div className="text-[9px] uppercase tracking-[0.1em] text-muted-foreground/35 mb-1 font-semibold">
                    Title
                  </div>
                  <div className="text-xs leading-snug">{selectedCard.title}</div>
                </div>
                <div>
                  <div className="text-[9px] uppercase tracking-[0.1em] text-muted-foreground/35 mb-1 font-semibold">
                    Phase
                  </div>
                  <div className="text-xs font-mono">{selectedCard.phase}</div>
                </div>
                <div>
                  <div className="text-[9px] uppercase tracking-[0.1em] text-muted-foreground/35 mb-1 font-semibold">
                    Assessed Risk
                  </div>
                  <RiskBadge level="high" />
                </div>
              </div>

              {isHighRisk && (
                <Notice type="warning">
                  This Work Card appears <strong>high risk.</strong> Do not
                  send it directly to Builder until the Architect reviews the
                  flagged items below.
                </Notice>
              )}

              {isLowRisk && (
                <Notice type="info">
                  No major risk flags detected. Normal Architect review is
                  still required before Builder handoff.
                </Notice>
              )}

              <div>
                <h3 className="text-xs font-semibold mb-1.5 text-foreground">
                  Summary
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {RISK_CATEGORIES.length} high-risk category signals detected.
                  Architect review should resolve the flagged items before
                  Builder handoff.
                </p>
              </div>

              <div>
                <h3 className="text-xs font-semibold mb-2.5 text-foreground">
                  Flagged Categories
                </h3>
                <div className="flex flex-col gap-2">
                  {RISK_CATEGORIES.map((cat) => (
                    <RiskCategoryCard key={cat.name} cat={cat} />
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xs font-semibold mb-2.5 text-foreground">
                  Scope-Creep Signals
                </h3>
                <div className="rounded-lg border border-amber-500/15 bg-amber-500/5 p-3">
                  <ul className="text-xs text-amber-200/65 space-y-1.5 list-disc list-inside leading-relaxed">
                    <li>
                      Mentions multiple large work types together: database,
                      authentication, deployment, cloud, provider integration,
                      MCP/connector integration.
                    </li>
                  </ul>
                </div>
              </div>

              <div>
                <h3 className="text-xs font-semibold mb-2.5 text-foreground">
                  Architect Review Questions
                </h3>
                <div className="rounded-lg border border-blue-500/15 bg-blue-500/5 p-3">
                  <ul className="text-xs text-blue-200/65 space-y-2 list-disc list-inside leading-relaxed">
                    {RISK_CATEGORIES.map((c) => (
                      <li key={c.name}>{c.question}</li>
                    ))}
                    <li>
                      Should this be split into a smaller Work Card before
                      Builder handoff?
                    </li>
                  </ul>
                </div>
              </div>
            </>
          ) : (
            <EmptyState
              message="Select a Work Card to run risk routing."
              icon={<ShieldAlert size={22} />}
            />
          )}
        </div>
      }
    />
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN 4 — Builder Prompt Generator  (Build)
// ═══════════════════════════════════════════════════════════════════════════════

function BuilderPromptScreen({ activeCard }: { activeCard: WorkCard | null }) {
  const [selectedCard, setSelectedCard] = useState<WorkCard | null>(
    activeCard || DEMO_CARDS[0]
  );
  const [artifacts, setArtifacts] = useState({
    workCardMd: false,
    architectPrompt: false,
    riskReview: false,
    priorReport: false,
  });
  const [copied, setCopied] = useState(false);
  const [savedPath, setSavedPath] = useState<string | null>(null);

  const toggle = (k: keyof typeof artifacts) => () =>
    setArtifacts((a) => ({ ...a, [k]: !a[k] }));

  const missingRiskReview = !artifacts.riskReview;

  const prompt = selectedCard
    ? `You are acting as Builder (Implementer) for ChampCity A/I.

This is a precise implementation handoff from the Architect. Build exactly what is described. Do not extend scope.

## Repository
/Users/operator/Projects/ChampCity_AI
Confirm git status and remote before editing.

## Work Card
Work Card ID: ${selectedCard.id}
Title: ${selectedCard.title}
Phase: ${selectedCard.phase}
Status: ${selectedCard.status}
Risk Level: ${selectedCard.riskLevel}

${missingRiskReview ? "⚠️  No Risk Review artifact included. Review the Work Card for scope-creep signals before proceeding.\n" : ""}
## Required Steps Before Editing
- [ ] Read Work Card ${selectedCard.id} from planning/phases/${selectedCard.phase}/Work_Cards/
- [ ] Run git status — confirm clean working tree.
- [ ] Run git branch and confirm remote.
- [ ] Review in-scope and out-of-scope constraints.

## Implementation
Implement the Work Card above. Make the minimum necessary changes. Confirm each file change against the scope before saving.

## On Completion
Produce a Builder Report containing:
- Commit hash.
- Files created and modified.
- Commands run and results.
- Validation performed.
- Blocking questions, if any.
- Recommended next Builder task.
`
    : null;

  const handleCopy = () => {
    if (!prompt) return;
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ScreenLayout
      left={
        <div className="p-4 flex flex-col gap-5">
          <div>
            <h1 className="text-sm font-semibold text-foreground">
              Builder Prompt Generator
            </h1>
            <p className="text-xs text-muted-foreground/60 mt-0.5 leading-snug">
              Generate the implementation handoff for Codex / Implementer.
            </p>
          </div>

          <Notice type="info">
            Only Work Cards with JSON artifacts can be selected.
            Markdown-only notes are not app-readable Work Cards.
          </Notice>

          <FieldGroup title="Source">
            <Field label="Phase">
              <select className={selectCls}>
                <option>phase-01</option>
              </select>
            </Field>
            <Field label="Saved Work Card JSON">
              <select
                className={selectCls}
                value={selectedCard?.id || ""}
                onChange={(e) => {
                  setSelectedCard(
                    DEMO_CARDS.find((c) => c.id === e.target.value) || null
                  );
                  setSavedPath(null);
                }}
              >
                <option value="">— select a Work Card —</option>
                {DEMO_CARDS.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.id} — {c.title} ({c.phase})
                  </option>
                ))}
              </select>
            </Field>
          </FieldGroup>

          {selectedCard && <WorkCardSummary card={selectedCard} />}

          <FieldGroup title="Supporting Artifacts">
            <Notice type="info">
              No matching Architect Prompt found. The prompt will include a
              missing-artifact note.
            </Notice>
            {(
              [
                "workCardMd",
                "architectPrompt",
                "riskReview",
                "priorReport",
              ] as const
            ).map((k) => (
              <label
                key={k}
                className="flex items-center gap-2.5 cursor-pointer group"
              >
                <input
                  type="checkbox"
                  checked={artifacts[k]}
                  onChange={toggle(k)}
                  className="accent-primary w-3.5 h-3.5 shrink-0"
                />
                <span className="text-xs text-muted-foreground group-hover:text-foreground transition-colors flex-1">
                  {
                    {
                      workCardMd: "Work Card Markdown",
                      architectPrompt: "Architect Prompt",
                      riskReview: "Risk Review",
                      priorReport: "Prior Builder Report",
                    }[k]
                  }
                </span>
                <span className="text-[10px] text-muted-foreground/35 font-mono">
                  {artifacts[k] ? "included" : "—"}
                </span>
              </label>
            ))}
          </FieldGroup>

          {missingRiskReview && (
            <Notice type="warning">
              No Risk Review artifact selected. The generated prompt will
              warn Builder not to proceed with high-risk changes before
              Architect sign-off.
            </Notice>
          )}

          {savedPath && (
            <Notice type="success">
              Saved — <span className="font-mono">{savedPath}</span>
            </Notice>
          )}

          <ActionBar
            onCopy={selectedCard ? handleCopy : undefined}
            onSave={
              selectedCard
                ? () =>
                    setSavedPath(
                      `planning/phases/phase-01/Builder_Prompts/BUILDER_PROMPT_${selectedCard.id}.md`
                    )
                : undefined
            }
            copyLabel={copied ? "Copied!" : "Copy Prompt"}
            saveLabel="Save Builder Prompt"
            saveDisabled={!selectedCard}
            copyDisabled={!selectedCard}
            statusMessage={
              copied
                ? "Copied to clipboard"
                : savedPath
                ? "Prompt saved"
                : undefined
            }
            statusType="success"
          />
        </div>
      }
      right={
        <ArtifactPanel
          eyebrow="Implementer Handoff"
          title="Builder Prompt"
          status={prompt ? "Builder prompt generated." : undefined}
          filename={
            savedPath
              ? `planning/phases/phase-01/Builder_Prompts/BUILDER_PROMPT_${selectedCard?.id}.md`
              : undefined
          }
          onCopy={selectedCard ? handleCopy : undefined}
          copyLabel={copied ? "Copied!" : "Copy"}
          copyDisabled={!selectedCard}
          emptyMessage="Select a Work Card to generate a Builder prompt."
          emptyIcon={<Zap size={22} />}
        >
          {prompt ? (
            <div className="flex flex-col gap-3">
              {missingRiskReview && (
                <Notice type="warning">
                  <strong>No Risk Review artifact included.</strong> Builder
                  will be warned not to proceed with high-risk changes before
                  Architect sign-off.
                </Notice>
              )}
              <MonoBlock className="max-h-[calc(100vh-220px)]">
                {prompt}
              </MonoBlock>
            </div>
          ) : undefined}
        </ArtifactPanel>
      }
    />
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN 5 — Builder Report Capture  (Report)
// ═══════════════════════════════════════════════════════════════════════════════

const DETECTION_COLS = [
  "Commit Hash",
  "Validation Results",
  "Blocking Questions",
  "Recommended Next Task",
];

function BuilderReportScreen({ activeCard }: { activeCard: WorkCard | null }) {
  const [reportType, setReportType] = useState("Work Card");
  const [selectedCard, setSelectedCard] = useState<WorkCard | null>(
    activeCard || DEMO_CARDS[0]
  );
  const [topic, setTopic] = useState(
    activeCard?.title || "Define Work Card schema and Markdown renderer"
  );
  const [reportText, setReportText] = useState("");
  const [savedPath, setSavedPath] = useState<string | null>(null);

  const slug = topic
    .toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[^a-z0-9_]/g, "");
  const filename = selectedCard
    ? `BUILDER_REPORT_${selectedCard.id}_${slug}.md`
    : `BUILDER_REPORT_${slug}.md`;

  const cannotSaveReasons = [
    !reportText && "Report text is empty.",
    !reportText &&
      "Report text does not include an obvious Builder Report heading.",
  ].filter(Boolean) as string[];

  return (
    <ScreenLayout
      left={
        <div className="p-4 flex flex-col gap-5">
          <div>
            <h1 className="text-sm font-semibold text-foreground">
              Builder Report Capture
            </h1>
            <p className="text-xs text-muted-foreground/60 mt-0.5 leading-snug">
              Record what the Implementer actually did.
            </p>
          </div>

          <Notice type="info">
            Only Work Cards with JSON artifacts can be selected.
          </Notice>

          <FieldGroup title="Report Source">
            <Field label="Phase">
              <select className={selectCls}>
                <option>phase-01</option>
              </select>
            </Field>
            <Field label="Report Type">
              <select
                className={selectCls}
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
              >
                {["Work Card", "Fix", "Repair", "Other"].map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </Field>
            <Field label="Saved Work Card JSON">
              <select
                className={selectCls}
                value={selectedCard?.id || ""}
                onChange={(e) =>
                  setSelectedCard(
                    DEMO_CARDS.find((c) => c.id === e.target.value) || null
                  )
                }
              >
                <option value="">— select —</option>
                {DEMO_CARDS.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.id} — {c.title}
                  </option>
                ))}
              </select>
            </Field>
            {selectedCard && <WorkCardSummary card={selectedCard} />}
          </FieldGroup>

          <FieldGroup title="Report Details">
            <Field label="Short topic / slug">
              <input
                className={inputCls}
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
              />
            </Field>
            <Field label="Import Markdown or text report">
              <label className="flex items-center gap-2 px-3 py-2 rounded-md border border-border bg-white/[0.02] text-xs text-muted-foreground hover:text-foreground cursor-pointer transition-colors w-fit">
                <Upload size={11} />
                Choose File
                <input type="file" className="hidden" accept=".md,.txt" />
              </label>
            </Field>
            <Field label="Generated filename">
              <FilenameDisplay filename={filename} />
            </Field>
          </FieldGroup>

          {savedPath && (
            <Notice type="success">
              Saved — <span className="font-mono">{savedPath}</span>
            </Notice>
          )}

          <ActionBar
            onSave={() =>
              setSavedPath(
                `planning/phases/phase-01/Builder_Reports/${filename}`
              )
            }
            saveLabel="Save Builder Report"
            saveDisabled={!reportText}
            statusMessage={savedPath ? "Builder report saved" : undefined}
            statusType="success"
          />
        </div>
      }
      right={
        <div className="p-5 flex flex-col gap-4">
          <div>
            <div className="text-[9px] uppercase tracking-[0.14em] font-bold text-primary/55 mb-1">
              Builder Report
            </div>
            <h2 className="text-sm font-semibold">Capture</h2>
          </div>

          <Field label="Paste or type the Builder Report">
            <textarea
              className={cn(textareaCls, "min-h-[180px]")}
              value={reportText}
              onChange={(e) => setReportText(e.target.value)}
              placeholder="Paste the Builder Report here…"
            />
          </Field>

          <div className="grid grid-cols-4 gap-2">
            {DETECTION_COLS.map((col) => (
              <div
                key={col}
                className="rounded-md border border-border bg-white/[0.02] p-2.5"
              >
                <div className="text-[9px] uppercase tracking-[0.08em] text-muted-foreground/35 mb-1.5 font-semibold leading-tight">
                  {col}
                </div>
                <div className="text-[11px] text-muted-foreground/50 font-mono">
                  Not detected
                </div>
              </div>
            ))}
          </div>

          {cannotSaveReasons.length > 0 && (
            <Notice type="error">
              <strong className="block mb-1.5">Cannot save yet</strong>
              <ul className="space-y-1 text-xs">
                {cannotSaveReasons.map((r, i) => (
                  <li key={i}>• {r}</li>
                ))}
                <li>
                  • Missing or unclear section: Repository path inspected.
                </li>
                <li>
                  • Missing or unclear section: Git branch and remote status.
                </li>
                <li>• Missing or unclear section: Files created.</li>
                <li>• Missing or unclear section: Files modified.</li>
                <li>
                  • Missing or unclear section: Commands run and results.
                </li>
                <li>• Missing or unclear section: Validation performed.</li>
                <li>• No commit hash was detected.</li>
              </ul>
            </Notice>
          )}
        </div>
      }
    />
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN 6 — Human Validation  (Validate)
// ═══════════════════════════════════════════════════════════════════════════════

function HumanValidationScreen({
  activeCard,
}: {
  activeCard: WorkCard | null;
}) {
  const [selectedCard, setSelectedCard] = useState<WorkCard | null>(
    activeCard || DEMO_CARDS[0]
  );
  const [builderReport, setBuilderReport] = useState("");
  const [form, setForm] = useState({
    result: "Not Tested",
    decision: "Deferred - not validated yet",
    tested: "",
    passed: "",
    failed: "",
    evidence: "",
    screenshots: "",
    commands: "",
    errors: "",
    observations: "",
    nextAction: "",
  });
  const [savedPath, setSavedPath] = useState<string | null>(null);

  const setF =
    (k: string) =>
    (e: React.ChangeEvent<HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [k]: e.target.value }));

  const needsRepair =
    form.result === "Failed" ||
    form.result === "Partial" ||
    form.result === "Blocked" ||
    form.decision === "Repair required";

  const repairPrompt = needsRepair && selectedCard
    ? `You are acting as Builder for a repair cycle.

Validation result: ${form.result}
Operator decision: ${form.decision}

Work Card: ${selectedCard.id} — ${selectedCard.title}

## What Failed
${form.failed || "(not entered)"}

## Observed Errors
${form.errors || "(not entered)"}

## Repair Instructions
Investigate the failure above. Make the minimum targeted changes to resolve the issue. Do not extend scope. Produce a Repair Builder Report on completion.`
    : null;

  const validationPreview = `# Validation Record — ${selectedCard?.id || ""}

Result: ${form.result}
Decision: ${form.decision}

## What Was Tested
${form.tested || "(not entered)"}

## What Passed
${form.passed || "(not entered)"}

## What Failed
${form.failed || "(not entered)"}

## Evidence References
${form.evidence || "(not entered)"}

## Recommended Next Action
${form.nextAction || "(not entered)"}`;

  return (
    <ScreenLayout
      left={
        <div className="p-4 flex flex-col gap-5">
          <div>
            <h1 className="text-sm font-semibold text-foreground">
              Human Validation
            </h1>
            <p className="text-xs text-muted-foreground/60 mt-0.5 leading-snug">
              Confirm whether the implementation actually worked.
            </p>
          </div>

          <FieldGroup title="Source">
            <Field label="Phase">
              <select className={selectCls}>
                <option>phase-01</option>
              </select>
            </Field>
            <Field label="Saved Work Card JSON">
              <select
                className={selectCls}
                value={selectedCard?.id || ""}
                onChange={(e) =>
                  setSelectedCard(
                    DEMO_CARDS.find((c) => c.id === e.target.value) || null
                  )
                }
              >
                <option value="">— select —</option>
                {DEMO_CARDS.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.id} — {c.title}
                  </option>
                ))}
              </select>
            </Field>
            {selectedCard && <WorkCardSummary card={selectedCard} />}
            <Field label="Associated Builder Report">
              <select
                className={selectCls}
                value={builderReport}
                onChange={(e) => setBuilderReport(e.target.value)}
              >
                <option value="">No Builder Report selected</option>
                <option value="BUILDER_REPORT_WC01_work_card_schema_renderer.md">
                  BUILDER_REPORT_WC01_work_card_schema_renderer.md
                </option>
              </select>
            </Field>
            {!builderReport && (
              <Notice type="warning">
                No Builder Report selected. You can still save validation, but
                the evidence chain is incomplete.
              </Notice>
            )}
          </FieldGroup>

          {savedPath && (
            <Notice type="success">
              Saved — <span className="font-mono">{savedPath}</span>
            </Notice>
          )}

          <ActionBar
            onSave={
              selectedCard
                ? () =>
                    setSavedPath(
                      `planning/phases/phase-01/Validation_Reports/VALIDATION_${selectedCard.id}.json`
                    )
                : undefined
            }
            saveLabel="Save Validation"
            saveDisabled={!selectedCard}
            statusMessage={savedPath ? "Validation saved" : undefined}
            statusType="success"
          />
        </div>
      }
      right={
        <div className="p-5 flex flex-col gap-4">
          <div>
            <div className="text-[9px] uppercase tracking-[0.14em] font-bold text-primary/55 mb-1">
              Operator Validation
            </div>
            <h2 className="text-sm font-semibold">Record</h2>
          </div>

          <FieldRow>
            <Field label="Validation result">
              <select
                className={selectCls}
                value={form.result}
                onChange={setF("result")}
              >
                {[
                  "Not Tested",
                  "Passed",
                  "Partial",
                  "Failed",
                  "Blocked",
                ].map((r) => (
                  <option key={r}>{r}</option>
                ))}
              </select>
            </Field>
            <Field label="Operator decision">
              <select
                className={selectCls}
                value={form.decision}
                onChange={setF("decision")}
              >
                {[
                  "Deferred - not validated yet",
                  "Validated - continue to closeout",
                  "Repair required",
                  "Different problem - open new card",
                ].map((d) => (
                  <option key={d}>{d}</option>
                ))}
              </select>
            </Field>
          </FieldRow>

          <Field label="What was tested?">
            <textarea
              className={textareaCls}
              value={form.tested}
              onChange={setF("tested")}
              rows={2}
            />
          </Field>

          <FieldRow>
            <Field label="What passed?">
              <textarea
                className={textareaCls}
                value={form.passed}
                onChange={setF("passed")}
                rows={3}
              />
            </Field>
            <Field label="What failed?">
              <textarea
                className={textareaCls}
                value={form.failed}
                onChange={setF("failed")}
                rows={3}
              />
            </Field>
          </FieldRow>

          <FieldRow>
            <Field label="Evidence references or paths">
              <textarea
                className={textareaCls}
                value={form.evidence}
                onChange={setF("evidence")}
                rows={2}
              />
            </Field>
            <Field label="Screenshots or files by path">
              <textarea
                className={textareaCls}
                value={form.screenshots}
                onChange={setF("screenshots")}
                rows={2}
              />
            </Field>
          </FieldRow>

          <FieldRow>
            <Field label="Manual commands run">
              <textarea
                className={textareaCls}
                value={form.commands}
                onChange={setF("commands")}
                rows={2}
              />
            </Field>
            <Field label="Observed errors">
              <textarea
                className={textareaCls}
                value={form.errors}
                onChange={setF("errors")}
                rows={2}
              />
            </Field>
          </FieldRow>

          <Field label="Additional Operator observations">
            <textarea
              className={textareaCls}
              value={form.observations}
              onChange={setF("observations")}
              rows={2}
            />
          </Field>

          <Field label="Recommended next action">
            <textarea
              className={textareaCls}
              value={form.nextAction}
              onChange={setF("nextAction")}
              rows={2}
            />
          </Field>

          {needsRepair ? (
            <div className="rounded-lg border border-amber-500/25 bg-amber-500/8 p-4 flex flex-col gap-3">
              <div className="flex items-center gap-2">
                <AlertTriangle size={13} className="text-amber-400 shrink-0" />
                <span className="text-xs font-semibold text-amber-200">
                  Repair path triggered —{" "}
                  <span className="font-mono font-normal">
                    {form.result}
                  </span>{" "}
                  / {form.decision}
                </span>
              </div>
              <p className="text-xs text-amber-100/65 leading-relaxed">
                A Repair Prompt will be generated and saved when you save the
                validation record. The repair prompt is scoped to the failed
                items above.
              </p>
              {repairPrompt && (
                <div>
                  <div className="text-[9px] uppercase tracking-widest text-amber-400/50 font-semibold mb-1.5">
                    Repair Prompt Preview
                  </div>
                  <MonoBlock className="max-h-36">{repairPrompt}</MonoBlock>
                </div>
              )}
            </div>
          ) : (
            <div className="px-3 py-2.5 rounded-md bg-white/[0.02] border border-border">
              <p className="text-xs text-muted-foreground/45 leading-relaxed">
                No Repair Prompt will be generated for the current result and
                Operator decision.
              </p>
            </div>
          )}

          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[9px] font-bold tracking-[0.12em] uppercase text-muted-foreground/35">
                Validation Preview
              </span>
              <div className="flex-1 h-px bg-white/[0.05]" />
            </div>
            <MonoBlock className="max-h-44">{validationPreview}</MonoBlock>
          </div>
        </div>
      }
    />
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREEN 7 — Phase Closeout
// ═══════════════════════════════════════════════════════════════════════════════

function PhaseCloseoutScreen() {
  const [form, setForm] = useState({
    decision: "Continue phase",
    summary: "",
    completed: "",
    remaining: "",
    risks: "",
    notes: "",
    nextAction: "",
  });
  const [savedPath, setSavedPath] = useState<string | null>(null);

  const setF =
    (k: string) =>
    (e: React.ChangeEvent<HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [k]: e.target.value }));

  const totalArtifacts = Object.values(ARTIFACT_SUMMARY).reduce(
    (s, v) => s + v.length,
    0
  );
  const missingArtifactGroups = Object.entries(ARTIFACT_SUMMARY).filter(
    ([, v]) => v.length === 0
  ).length;

  const closeoutPreview = `# Phase Closeout Report — phase-01

## Closeout Decision
${form.decision}

## Closeout Summary
${form.summary || "(not entered)"}

## Artifact Summary
Total artifacts: ${totalArtifacts}
Folders with no artifacts: ${missingArtifactGroups}

## Completed Items
${form.completed || "(not entered)"}

## Remaining Items
${form.remaining || "(not entered)"}

## Known Risks
${form.risks || "(not entered)"}

## Operator Notes
${form.notes || "(not entered)"}

## Recommended Next Action
${form.nextAction || "(not entered)"}

## Deterministic Recommendation
Phase appears ready for closeout review. Phase lacks validation reports.
Confirm manual validation evidence before closing.`;

  return (
    <ScreenLayout
      left={
        <div className="p-4 flex flex-col gap-5">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h1 className="text-sm font-semibold text-foreground">
                Phase Closeout
              </h1>
              <p className="text-xs text-muted-foreground/60 mt-0.5 leading-snug">
                Decide whether the phase is complete, needs repair, or is ready
                for release.
              </p>
            </div>
            <Badge className="text-muted-foreground/50 bg-white/[0.03] border-border text-[9px] shrink-0">
              phase-01
            </Badge>
          </div>

          <FieldGroup title="Phase Artifacts">
            {Object.entries(ARTIFACT_SUMMARY).map(([label, files]) => (
              <div key={label} className="flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground/70">
                    {label}
                  </span>
                  <span
                    className={cn(
                      "text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded border",
                      files.length === 0
                        ? "text-amber-400 bg-amber-400/8 border-amber-400/20"
                        : "text-emerald-400 bg-emerald-400/8 border-emerald-400/20"
                    )}
                  >
                    {files.length}
                  </span>
                </div>
                {files.length > 0 && (
                  <div className="space-y-0.5 pl-2">
                    {files.map((f) => (
                      <div
                        key={f}
                        className="text-[10px] font-mono text-muted-foreground/35 truncate"
                      >
                        {f}
                      </div>
                    ))}
                  </div>
                )}
                {files.length === 0 && (
                  <div className="text-[10px] text-amber-400/50 pl-2">
                    No artifacts found.
                  </div>
                )}
              </div>
            ))}
          </FieldGroup>

          {savedPath && (
            <Notice type="success">
              Saved — <span className="font-mono">{savedPath}</span>
            </Notice>
          )}

          <ActionBar
            onSave={() =>
              setSavedPath(
                "planning/phases/phase-01/Closeout_Reports/CLOSEOUT_phase-01.json"
              )
            }
            saveLabel="Save Closeout"
            statusMessage={savedPath ? "Closeout saved" : undefined}
            statusType="success"
          />
        </div>
      }
      right={
        <div className="p-5 flex flex-col gap-5">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-[9px] uppercase tracking-[0.14em] font-bold text-primary/55 mb-1">
                Phase Closeout
              </div>
              <h2 className="text-sm font-semibold">Decision Record</h2>
            </div>
            <span className="text-[10px] text-muted-foreground/50 bg-white/[0.03] px-2 py-1 rounded border border-border">
              Phase Closeout preview refreshed.
            </span>
          </div>

          <div className="rounded-lg border border-border bg-card p-4 grid grid-cols-4 gap-4">
            {[
              {
                label: "Total Artifacts",
                val: totalArtifacts,
                color: "text-foreground",
              },
              {
                label: "Work Cards",
                val: ARTIFACT_SUMMARY["Work Cards"].length,
                color: "text-foreground",
              },
              {
                label: "Paired JSON + MD",
                val: ARTIFACT_SUMMARY["Work Cards"].length,
                color: "text-emerald-400",
              },
              {
                label: "Missing Artifacts",
                val: missingArtifactGroups,
                color:
                  missingArtifactGroups > 0
                    ? "text-amber-400"
                    : "text-emerald-400",
              },
            ].map(({ label, val, color }) => (
              <div key={label} className="text-center">
                <div className={cn("text-xl font-semibold tabular-nums", color)}>
                  {val}
                </div>
                <div className="text-[9px] text-muted-foreground/45 mt-0.5 leading-tight">
                  {label}
                </div>
              </div>
            ))}
          </div>

          <Notice type="info">
            Phase appears ready for closeout review. Phase lacks validation
            reports. Confirm manual validation evidence before closing.
          </Notice>

          <div className="rounded-lg border border-border bg-card/50 p-3.5">
            <div className="text-[9px] uppercase tracking-[0.1em] text-muted-foreground/35 mb-1.5 font-semibold">
              Deterministic Recommendation
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Phase appears ready for closeout review. Phase lacks validation
              reports. Confirm manual validation evidence before closing.
            </p>
          </div>

          <FieldGroup title="Decision">
            <Field label="Closeout decision">
              <select
                className={selectCls}
                value={form.decision}
                onChange={setF("decision")}
              >
                {["Continue phase", "Close phase", "Defer closeout"].map(
                  (d) => (
                    <option key={d}>{d}</option>
                  )
                )}
              </select>
            </Field>
            <Field label="Closeout summary">
              <textarea
                className={textareaCls}
                value={form.summary}
                onChange={setF("summary")}
                rows={2}
              />
            </Field>
            <FieldRow>
              <Field label="What was completed?">
                <textarea
                  className={textareaCls}
                  value={form.completed}
                  onChange={setF("completed")}
                  rows={2}
                />
              </Field>
              <Field label="What remains?">
                <textarea
                  className={textareaCls}
                  value={form.remaining}
                  onChange={setF("remaining")}
                  rows={2}
                />
              </Field>
            </FieldRow>
            <FieldRow>
              <Field label="Known risks">
                <textarea
                  className={textareaCls}
                  value={form.risks}
                  onChange={setF("risks")}
                  rows={2}
                />
              </Field>
              <Field label="Operator notes">
                <textarea
                  className={textareaCls}
                  value={form.notes}
                  onChange={setF("notes")}
                  rows={2}
                />
              </Field>
            </FieldRow>
            <Field label="Recommended next action">
              <textarea
                className={textareaCls}
                value={form.nextAction}
                onChange={setF("nextAction")}
                rows={2}
              />
            </Field>
          </FieldGroup>

          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[9px] font-bold tracking-[0.12em] uppercase text-muted-foreground/35">
                Closeout Preview
              </span>
              <div className="flex-1 h-px bg-white/[0.05]" />
            </div>
            <MonoBlock className="max-h-56">{closeoutPreview}</MonoBlock>
          </div>
        </div>
      }
    />
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// APP ROOT
// ═══════════════════════════════════════════════════════════════════════════════

export default function App() {
  const [screen, setScreen] = useState<Screen>("new-work-card");
  const [phase, setPhase] = useState("phase-01");
  const [activeCard, setActiveCard] = useState<WorkCard | null>(null);

  const screens: Record<Screen, React.ReactNode> = {
    "new-work-card": <NewWorkCardScreen activeCard={activeCard} />,
    "architect-prompt": <ArchitectPromptScreen activeCard={activeCard} />,
    "risk-router": <RiskRouterScreen activeCard={activeCard} />,
    "builder-prompt": <BuilderPromptScreen activeCard={activeCard} />,
    "builder-report": <BuilderReportScreen activeCard={activeCard} />,
    "human-validation": <HumanValidationScreen activeCard={activeCard} />,
    "phase-closeout": <PhaseCloseoutScreen />,
  };

  return (
    <div
      className="flex flex-col h-screen overflow-hidden bg-background text-foreground"
      style={{ fontFamily: "'Inter', system-ui, sans-serif" }}
    >
      <AppHeader
        active={screen}
        onNav={setScreen}
        phase={phase}
        onPhaseChange={setPhase}
        activeCard={activeCard}
        onCardChange={setActiveCard}
      />
      <div className="flex-1 overflow-hidden">{screens[screen]}</div>
    </div>
  );
}
