Design a compact, modern, dark-mode Electron desktop UI for **ChampCity A/I**.

Important product meaning:
`A/I` is a play on AI, but it means **Architect / Implementer**.

The app is not a generic project tracker, ticket queue, admin dashboard, or developer tool. It is a guided workflow cockpit for a non-developer Operator who uses ChatGPT as the **Architect** and Codex or another coding agent as the **Implementer**.

The UI must clearly teach and support this flow:

**Capture → Architect → Risk → Build → Report → Validate → Closeout**

The Operator does not jump randomly between tools. They move a Work Card through a sequence.

## Core workflow model

The central object is a **Work Card**.

A Work Card is the smallest buildable unit of work that can be handed to an Implementer.

The Operator starts with plain-language intent. The app turns that intent into structured artifacts used across the workflow.

The app should make the user feel like they are moving one Work Card through a polished guided process:

1. **Capture**

   * Screen: New Work Card
   * Operator enters plain-language intent.
   * Output: paired JSON and Markdown Work Card artifacts.
   * Status: draft / ready for Architect review.
   * UI meaning: “Tell the system what you want to build or fix.”

2. **Architect**

   * Screen: Architect Prompt Composer
   * Operator selects a Work Card.
   * App generates a copy-ready prompt for ChatGPT Architect.
   * Output: Architect prompt Markdown artifact.
   * UI meaning: “Have the Architect refine the Work Card before Builder handoff.”

3. **Risk**

   * Screen: Risk Router
   * Operator selects a Work Card.
   * App runs deterministic risk checks.
   * Output: Risk Review Markdown artifact.
   * UI meaning: “Identify whether this Work Card needs extra caution before implementation.”

4. **Build**

   * Screen: Builder Prompt Generator
   * Operator selects the Work Card and optional supporting artifacts.
   * App generates a copy-ready Builder prompt for Codex / Implementer.
   * Output: Builder Prompt Markdown artifact.
   * UI meaning: “Generate the implementation handoff.”

5. **Report**

   * Screen: Builder Report Capture
   * Operator pastes or imports the Builder’s report after implementation.
   * App validates report structure with warnings.
   * Output: Builder Report Markdown artifact.
   * UI meaning: “Record what the Implementer actually did.”

6. **Validate**

   * Screen: Human Validation
   * Operator records manual testing results.
   * If validation fails, partials, or blocks, app generates a Repair Prompt.
   * Output: Validation Report JSON/Markdown and optional Repair Prompt.
   * UI meaning: “Confirm whether the work really worked.”

7. **Closeout**

   * Screen: Phase Closeout
   * Operator reviews phase artifacts and records closeout decision.
   * Output: Closeout Report JSON/Markdown.
   * UI meaning: “Decide whether the phase is complete, needs repair, needs UI cleanup, or is ready for release/package planning.”

## Design goal

The current design looks too much like a narrow admin sidebar plus dense form panels. Redesign it so the workflow is self-explanatory, compact, and visually appealing to a consumer end user.

Preferred feel:

* Compact modern dark UI.
* Consumer-grade polish.
* Guided creative cockpit.
* Calm, confident, organized.
* Clear sense of progress through a pipeline.
* Less “work ticket system,” more “AI-assisted build studio.”
* More approachable for a non-developer Operator.

Avoid:

* Enterprise admin dashboard aesthetic.
* Ticket queue visuals.
* Dense developer-console look.
* Raw Markdown as the dominant first impression.
* Giant unbroken forms.
* Overly playful game UI.
* Confusing navigation where every tool looks equally independent.

## Navigation model

Do not present the seven screens as unrelated sidebar tools.

Design navigation around the pipeline:

**Capture → Architect → Risk → Build → Report → Validate → Closeout**

The UI should make the current step obvious and show what has already been completed.

Use a horizontal or hybrid stepper/progress rail that visually communicates sequence. A left sidebar can exist, but it should support the workflow rather than look like an admin menu.

The Operator should understand:

* “I am working on this Work Card.”
* “This is the current step.”
* “These artifacts already exist.”
* “This is the next recommended action.”

## Recommended layout concept

Use a three-zone layout:

1. **Workflow Header**

   * Product name: ChampCity A/I
   * Subtitle or small brand line: Architect / Implementer
   * Current phase selector, e.g. phase-01
   * Current Work Card selector or active Work Card card
   * Pipeline step indicator:
     Capture / Architect / Risk / Build / Report / Validate / Closeout

2. **Primary Work Area**

   * The active step’s form, preview, or action panel.
   * Group fields into compact cards.
   * Use progressive disclosure where possible.
   * Avoid long uninterrupted forms.
   * Emphasize the next action.

3. **Artifact / Context Panel**

   * Show generated artifacts and saved paths.
   * Show warnings, missing items, validation status, risk badges, and next-step guidance.
   * This panel should feel like context, not clutter.

## Screen-specific design expectations

### New Work Card

This is the start of the journey.
The screen should feel like a guided intake, not a requirements document.

Use plain-language groupings:

* What are you trying to build or fix?
* Why does it matter?
* What should the user be able to do?
* What should be included?
* What should not be included?
* Evidence, examples, concerns.

Show a live artifact preview, but do not make Markdown dominate the UI.

### Architect Prompt Composer

This screen should feel like sending the Work Card to the Architect.

Show:

* Selected Work Card.
* What the Architect will review.
* Generated Architect prompt.
* Copy Prompt.
* Save Prompt.

Emphasize:
“The Architect translates Operator intent into a Builder-ready Work Card.”

### Risk Router

This screen should feel like a pre-flight safety check.

Show:

* Risk level badge.
* Flagged categories.
* Architect review questions.
* Scope-creep signals.
* Save Risk Review.

High risk should look serious but not alarming.

Low risk must not imply automatic approval. Use language like:
“No major risk flags detected. Normal Architect review is still required.”

### Builder Prompt Generator

This is the Implementer handoff screen.

Show:

* Selected Work Card.
* Selected supporting artifacts.
* Missing-risk-review warning if no Risk Review is selected.
* Generated Builder prompt.
* Copy Prompt.
* Save Builder Prompt.

The design should make it clear this is where Codex/Implementer receives instructions.

### Builder Report Capture

This screen records what the Implementer did.

Show:

* Associated Work Card.
* Report type: Work Card / Fix / Repair / Other.
* Paste/import report.
* Validation warnings.
* Generated filename.
* Save Report.

It should feel like evidence capture, not text dumping.

### Human Validation

This screen is where the Operator confirms whether the implementation worked.

Show:

* Selected Work Card.
* Associated Builder Report.
* Extracted manual validation checklist if available.
* Operator validation fields.
* Decision:
  Passed / Failed / Partial / Blocked / Deferred / Different problem found.
* Repair Prompt preview only when needed.

Make the repair path visually clear:
Fail / Partial / Blocked → Repair Prompt.

### Phase Closeout

This screen summarizes the whole phase.

It should not feel like a generic dashboard. It should feel like a phase review.

Show:

* Artifact counts.
* Work Card JSON/Markdown pairing status.
* Missing artifacts or warnings.
* Deterministic recommendation.
* Closeout decision.
* Closeout notes.
* Save Closeout.

## Visual style

Use a refined dark palette:

* Deep charcoal / near-black background.
* Slightly elevated cards.
* Subtle borders.
* Soft teal or cyan accent for active Architect/Implementer flow.
* Amber for warnings.
* Red only for true blocking risk.
* Muted text for secondary metadata.
* Strong readable contrast.

Typography:

* Clean modern sans-serif.
* Compact but not cramped.
* Clear hierarchy.
* Avoid tiny low-contrast labels.

Components to design:

* App shell.
* Workflow stepper.
* Active Work Card card.
* Phase selector.
* Artifact count cards.
* Artifact selector.
* Compact input groups.
* Preview panel.
* Markdown preview treatment.
* Risk badge.
* Warning / notice / success banners.
* Copy/save action bar.
* Empty states.
* Validation checklist card.
* Repair prompt preview.
* Closeout summary card.

## Important functional preservation

The redesign must preserve all existing workflows and artifact concepts:

* Work Cards save as JSON and Markdown.
* Architect Prompts save as Markdown.
* Risk Reviews save as Markdown.
* Builder Prompts save as Markdown.
* Builder Reports save as Markdown.
* Validation Reports save as JSON and Markdown.
* Repair Prompts save as Markdown.
* Closeout Reports save as JSON and Markdown.

Do not add new product concepts like accounts, cloud sync, login, team management, billing, deployment, databases, or provider SDKs.

Do not remove the manual copy/paste MVP model. The UI should make copy/paste feel intentional and polished.

## Deliverable expected from Figma

Create a React-friendly desktop UI design for the full workflow.

Provide:

* Main app shell.
* The full seven-step workflow navigation.
* Representative screen designs for all seven workflow steps.
* Reusable component system.
* Warning/error/success/empty states.
* Compact artifact preview treatment.
* Notes for how Codex should map the design back to the existing React/Electron implementation.

The final design should communicate:

“ChampCity A/I helps a non-developer Operator guide work from idea to Architect framing, Implementer handoff, Builder evidence, human validation, repair, and closeout.”

It should feel like a polished consumer AI workflow studio, not an internal work tracker.
